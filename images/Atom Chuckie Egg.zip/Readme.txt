===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM (#0000-#7FFF)
- 6 KB video RAM (#8000-#97FF)
- VIA

===================================================================
Keys:
===================================================================

	, - Left
	. - Right
	A - Up
	Z - Down
  SPACE - Jump
      H - Hold
ESC + H - Quit game

If you press fire in the attraction screens, the joystick will be enabled.

===================================================================
Joystick (optional):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
software version 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

===================================================================
Tape version:
===================================================================

MCHUCK.CSW , Cassette Tape image for Atomulator emulator monochrome
MCHUCK.UEF , Cassette Tape image for Atomulator emulator monochrome
MCHUCK.TAP , Cassette Tape image for emulator Wouter Ras monochrome
CCHUCK.CSW , Cassette Tape image for Atomulator emulator colour
CCHUCK.UEF , Cassette Tape image for Atomulator emulator colour
CCHUCK.TAP , Cassette Tape image for emulator Wouter Ras colour

To start the game, type: *RUN "CHUCKIE"

===================================================================
Disc version:
===================================================================

CHUCKIE.DSK , Disc image for emulators

To start the game, type: *RUN "runme"

===================================================================
Source code:
===================================================================

The sourcefiles are compiled with the 2500AD cross compiler.

Type MAKE CHUCKIE -t to compile the program.

An assembler listing is created with the -t parameter in the
report.txt file.