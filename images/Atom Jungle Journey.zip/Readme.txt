----------------------------------------------
JUNGLE JOURNEY
 Original version for the Electron by David Boddie
 Atom conversion by Kees van Oss 2012

 Original game Copyright 2011 David Boddie <david@boddie.org.uk>
 Acorn Atom port Copyright 2012, Kees van Oss

    This file is part of Jungle Journey.

    Jungle Journey is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Jungle Journey is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Jungle Journey.  If not, see <http://www.gnu.org/licenses/>.

----------------------------------------------

===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 6 KB video RAM (#8000-#97FF)
- VIA

===================================================================
Keys:
===================================================================

	Z - Left
	X - Right
	; - Up
	. - Down
	S - Sound on
	Q - Sound off
	P - Pause
	O - Resume
      ESC - Restart

If you press fire in the intro screens, the joystick will be enabled.

===================================================================
Joystick (optional):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

===================================================================
Tape version:
===================================================================

JUNGLE.CSW , Tapefile colour version for Atomulator emulator
JUNGLE.UEF , Tapefile colour version for Atomulator emulator
JUNGLE.TAP , Tapefile colour version emulator Wouter Ras

To start the game, type: *RUN"JUNGLE"

===================================================================
Disk version:
===================================================================

JUNGLE.DSK , Diskfile colour version for emulators

To start the game, type: *RUN"runme"

===================================================================
Source:
===================================================================

The sourcefiles are compiled with the CC65 cross compiler.
Make sure that the files CA65.EXE and LD65.EXE are in a 
directory called BIN in the same directory as the source.
 
Type MAKE JUNGLE to compile the program.

An assembler listing is created in the JUNGLE.LST file.
